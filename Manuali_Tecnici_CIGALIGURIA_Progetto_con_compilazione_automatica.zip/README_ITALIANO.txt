PROGETTO ANDROID – MANUALI TECNICI CIGALIGURIA

Questo archivio contiene il progetto sorgente Android Studio (non è ancora un APK compilato).
La schermata web è inclusa negli asset e funziona offline dentro l'app.
I PDF vengono archiviati nel database locale IndexedDB del WebView; il pulsante Apri passa il PDF
al visualizzatore PDF installato sul telefono.

COME OTTENERE L'APK:
1. Apri il progetto in Android Studio.
2. Attendi la sincronizzazione Gradle e installa Android SDK 35 se richiesto.
3. Seleziona Build > Build Bundle(s) / APK(s) > Build APK(s).
4. L'APK di debug sarà in app/build/outputs/apk/debug/app-debug.apk.

Prima di sostituire la vecchia app, esporta il backup JSON dalla vecchia app se contiene manuali.
I dati della vecchia app non vengono trasferiti automaticamente in questa APK.


COMPILAZIONE AUTOMATICA SENZA ANDROID STUDIO (GitHub Actions):
Nel progetto è presente .github/workflows/build-apk.yml.
Carica il contenuto di questo progetto in un repository GitHub e apri la scheda
Actions. Avvia "Compila APK Android" (Run workflow) oppure attendi la compilazione
dopo un push su main. Al termine apri il workflow completato, scarica l'artifact
"Manuali-Tecnici-CIGALIGURIA-APK" e dentro troverai app-debug.apk.
Questa procedura richiede un account GitHub e una connessione Internet.
